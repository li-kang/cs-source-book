﻿using System;

namespace Card
{
    enum CardFlower
    {
        RedHeart,
        RedSquare,
        BlackHeart,
        BlackSquare
    }

    struct Card
    {
        public int Number;
        public CardFlower Flower;
    }


    class Program
    {
        const int CARD_COUNT = 54;
        static Card[] cards = new Card[CARD_COUNT];
        static Card[] playerA = new Card[CARD_COUNT];
        static Card[] playerB = new Card[CARD_COUNT];

        // 用于产生随机数的对象
        static Random r = new Random();
        // 当前起牌的索引
        static int cardIndex = 0;

        static void Main(string[] args)
        {
            // 初始化一套新牌
            Init();
            // 洗牌
            ExchangeCards();

            // 轮到A了
            double scoreA = PlayA();
            // 轮到B了
            double scoreB = PlayB();

            // 比较大小
            int result = Compare(scoreA, scoreB);

            switch (result)
            {
                case 0:
                    Console.WriteLine("平局");
                    break;
                case 1:
                    Console.WriteLine("A获胜");
                    break;
                case 2:
                    Console.WriteLine("B获胜");
                    break;
            }
        }
        // 返回0表示平局、1表示玩家A获胜、2表示玩家B获胜。
        static int Compare(double scoreA, double scoreB)
        {
            // 玩家A和玩家B都爆了。
            if (scoreA > 10.5 && scoreB > 10.5)
                return 0;

            // 玩家A爆了，玩家B没爆。
            if (scoreA > 10.5)
                return 2;

            // 玩家B爆了，玩家A没爆。
            if (scoreB > 10.5)
                return 1;

            // 都没爆，比较分数大小。
            if (scoreA > scoreB)
                return 1;
            else if (scoreB > scoreA)
                return 2;
            else
                return 0;
        }

        private static double PlayB()
        {
            int myCardIndex = 0;
            double score = 0;

            while (true)
            {
                Console.WriteLine("轮到PlayerB起牌[b:起牌, p：过]:");

                string input = Console.ReadLine();
                if (input == "b")
                {
                    playerB[myCardIndex] = cards[cardIndex];
                    // 提示起到的牌
                    Show(cards[cardIndex]);

                    // 计算得分
                    score += Score(cards[cardIndex]);

                    // 提示总分
                    Console.WriteLine("当前得分：" + score);

                    cardIndex++;
                    myCardIndex++;
                }
                else if (input == "p")
                {
                    // 过
                    break;
                }
                else
                {
                    Console.WriteLine("输入有误.");
                }
            }

            return score;
        }

        static double PlayA()
        {
            int playerCardIndex = 0;
            double score = 0;

            while (true)
            {
                Console.WriteLine("轮到PlayerA起牌[a:起牌, p：过]:");

                string input = Console.ReadLine();
                if (input == "a")
                {
                    playerA[playerCardIndex] = cards[cardIndex];
                    // 提示起到的牌
                    Show(cards[cardIndex]);

                    // 计算得分
                    score += Score(cards[cardIndex]);

                    // 提示总分
                    Console.WriteLine("当前得分：" + score);

                    cardIndex++;
                    playerCardIndex++;
                }
                else if (input == "p")
                {
                    // 过
                    break;
                }
                else
                {
                    Console.WriteLine("输入有误.");
                }
            }

            return score;
        }

        private static double Score(Card card)
        {
            if (card.Number >= 11)
                return 0.5;
            else
                return card.Number;
        }

        // 显示一张卡牌
        static void Show(Card card)
        {
            Card[] temp = { card };
            Show(temp);
        }

        static void Show(Card[] cs)
        {
            // 显示cs中所有卡牌
            // 这是典型的遍历数组的方法
            for (int i = 0; i < cs.Length; i++)
            {
                // 不显示没有初始化的卡牌
                if (cs[i].Number == 0)
                    continue;

                // 遍历时每一个元素为cs[i]
                // 显示某一张卡牌
                string cn;

                switch (cs[i].Number)
                {
                    case 1: cn = "A"; break;
                    case 11: cn = "J"; break;
                    case 12: cn = "Q"; break;
                    case 13: cn = "K"; break;
                    case 14: cn = "小王"; break;
                    case 15: cn = "大王"; break;
                    default:
                        cn = cs[i].Number.ToString();
                        break;
                }

                cn = (cs[i].Number < 14 ? cs[i].Flower + " " : "") + cn;
                Console.WriteLine(cn);
            }
        }

        // 显示所有卡牌
        static void Show()
        {
            Show(cards);
        }

        static void Init()
        {
            int index = 0;

            // 初始化卡牌
            for (int i = 1; i <= 13; i++)
            {
                // (每个数字)有4种花色
                for (int j = 0; j < 4; j++)
                {
                    cards[index] = new Card();
                    cards[index].Number = i;
                    cards[index].Flower = (CardFlower)j;

                    // 初始化了一张
                    index++;
                }
            }

            // 大小王特殊处理
            cards[52].Number = 14;  // 用14表示小王
            cards[53].Number = 15;  // 用15表示大王
        }

        // 将一个复杂的问题分解成一个个简单的问题
        // 同一时间只解决一个问题
        // 在写代码的过程中,将描述变得更明确.
        // 洗牌，默认洗1000次。
        static void ExchangeCards(int count = 1000)
        {
            // 交换count次
            for (int i = 0; i < count; i++)
            {
                // 随机找两张牌
                int index1 = r.Next(CARD_COUNT);
                int index2 = r.Next(CARD_COUNT);

                // 交换
                Card temp = cards[index1];
                cards[index1] = cards[index2];
                cards[index2] = temp;
            }
        }
    }
}
