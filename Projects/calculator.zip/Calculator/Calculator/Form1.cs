﻿using System;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Form1 : Form
    {
        const string EMPTY_TEXT = "";
// 第一个操作数
double number1;
// 运算符
string operate;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCE_Click(object sender, EventArgs e)
        {
            // 面向对象的编程，要说明是谁（txtData）的属性和方法。
            // 将txtData的文本(Text)设为 Hello World
            //txtData.Text = "Hello World";

            // 清空文本
            // 将txtData的文本(Text)设为空
            txtData.Text = EMPTY_TEXT;
        }

        private void btnBackspace_Click(object sender, EventArgs e)
        {
            // 去掉最后一位
            if (txtData.Text.Length > 0)
                txtData.Text = txtData.Text.Substring(0, txtData.Text.Length - 1);

            if (txtData.Text.Length == 0)
                txtData.Text = EMPTY_TEXT;
        }

        private void Number_Click(object sender, EventArgs e)
        {
            // 追加文字
            string txt = txtData.Text + ((Button)sender).Text;
            
            // 尝试将字符串转化为数字，以确认数据是合理的。
            double data;
            if (Double.TryParse(txt, out data))
            {
                txtData.Text = data.ToString();
                // 如果点击的是小数点，就把小数点追加到输入框。
                if (((Button)sender).Text == ".")
                    txtData.Text += ".";
            }
        }

        private void btnSign_Click(object sender, EventArgs e)
        {
            // 判断数据前是否有负号
            if (txtData.Text.StartsWith("-"))
            {
                // 去掉负号
                txtData.Text = txtData.Text.Substring(1);
            }
            else
            {
                // 加上负号
                txtData.Text = "-" + txtData.Text;
            }
        }

        // 运算，并将运算的结果保存到number1中，以便进一步运算。
        private void Compute()
        {
            // 第一个操作数保存在number1中
            // 运算符保存在operate中
            // 第二个操作数显示在文本框中
            // 能拿到这三个数据就可运算了

            // 如果没有第二个操作数，就不运算了。
            double number2;
            if (!Double.TryParse(txtData.Text, out number2))
                return;

            // 计算，并将运算的结果保存到number1中，以便进一步运算。
            switch (operate)
            {
                case "+": number1 = number1 + number2; break;
                case "-": number1 = number1 - number2; break;
                case "×": number1 = number1 * number2; break;
                case "÷": number1 = number1 / number2; break;
                default: number1 = number2; break;
            }
        }

        private void Operator_Click(object sender, EventArgs e)
        {
            // 将之前的数据进行运算，结果存入第一个运算数。
            Compute();

            // 记录操作符
            operate = ((Button)sender).Text;

            // 显示计算历史
            lblCompute.Text = number1 + " " + operate;
            // 清空输入框，方便输入第二个操作数。
            txtData.Text = EMPTY_TEXT;
        }

        private void btnCompute_Click(object sender, EventArgs e)
        {
            // 运算
            Compute();

            // 显示结果
            txtData.Text = number1.ToString();
            lblCompute.Text = txtData.Text;

            // 计算完了就清除operate，防止再次运算。
            operate = null;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            // 清空所有的显示数据
            txtData.Text = EMPTY_TEXT;
            lblCompute.Text = null;

            // 还原所有的变量
            number1 = 0;
            operate = null;
        }
    }
}
